import logging
from logging.config import fileConfig
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import engine_from_config
from sqlalchemy import pool
from alembic import context
from core.config import settings
from models.base import Base

# Import ALL models so Alembic auto-discovers every table
from models.masters import State, District, Taluk, PostalCode, MembershipType, MembershipTypePrice, HmsSetting, DocumentType, ServiceType, Bank
from models.users import User, Role, Permission, RolePermission
from models.members import (
    Member, MemberMembership, MemberDocument, MemberApprovalHistory,
    MemberProfileChangeRequest, MemberProfileHistory, MembershipTypeChangeRequest,
    MembershipTypeHistory, MemberDeletionRequest, MemberKycRequest
)
from models.receipts import Receipt, ReceiptItem, ReceiptAllocation, PaymentTransaction, ReceiptCancellation, RefundTransaction
from models.magazines import MagazineSubscription, MagazineDeliveryPause, MagazineReturn, MagazineDeliveryBatch, MagazineLabelBatch, MagazineLabelBatchItem
from models.events import Event, EventParticipant, EventMemberLink, EventAttachment
from models.engagements import (
    Affiliation, AffiliationContact, AffiliationMagazineSetting,
    Associate, AssociateMagazineSetting,
    PressMedia, PressMediaMagazineSetting,
    CommitteeCategory, CommitteeSubcategory, CommitteeTerm, CommitteeMember, CommitteeMemberLink
)
from models.notifications import (
    NotificationTemplate, NotificationCampaign, NotificationRecipient,
    NotificationMessage, NotificationDeliveryLog, NotificationImportBatch
)
from models.reports import SavedReport, ReportExportLog
from models.activity import UserActivityLog, MemberActivityLog
from models.system import RefreshToken, PasswordResetToken, FileAttachment, ApprovalWorkflow, ApprovalAction, NumberSequence, SystemErrorLog

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Override sqlalchemy.url from settings and escape % for ConfigParser
config.set_main_option("sqlalchemy.url", str(settings.DATABASE_URL).replace("%", "%%"))

target_metadata = Base.metadata

def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
